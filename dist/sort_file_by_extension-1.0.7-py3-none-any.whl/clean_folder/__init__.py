from clean_folder.sort import main

__all__ = ['main']